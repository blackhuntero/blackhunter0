/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package githubprueba;

/**
 *
 * @author Miguel
 */
public class GitHubPrueba {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Aqui no hay anda profe, solo es para ver si hice bien lo de GitHub");
    }
    
}
